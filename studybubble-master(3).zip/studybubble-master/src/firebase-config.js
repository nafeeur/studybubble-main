// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDnsOC1T1oYnUtyOvKwGMHTnWQe0G8axUI",
  authDomain: "codefest-fb4f1.firebaseapp.com",
  projectId: "codefest-fb4f1",
  storageBucket: "codefest-fb4f1.appspot.com",
  messagingSenderId: "893616484551",
  appId: "1:893616484551:web:906cc2c573224c3df00ee2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);