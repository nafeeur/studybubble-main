import React from 'react';
import logo from './images/Study.png'; 


export default function Logo() {
  return <img src={logo} alt="Logo" height={400} width={400} />;

}

